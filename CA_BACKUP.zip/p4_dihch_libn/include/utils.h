#ifndef __UTILS_H
#define __UTILS_H

int Get_Button(int ch);
int Get_BOOT0(void);

#endif