#ifndef TRANSLATOR_H
#define TRANSLATOR_H


int translate(const char*in, const char*out);


#endif