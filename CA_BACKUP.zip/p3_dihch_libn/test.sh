echo "small_test"
./gbfloat_fast ./test.jpg ./test_fast.jpg 0.6 -2.0 2.0 79 79
./gbfloat_fast ./test.jpg ./test_fast.jpg 0.2 -4.0 4.0 421 411
./gbfloat_fast ./test.jpg ./test_fast.jpg 0.4 -1.0 1.0 999 691
./gbfloat_fast ./test.jpg ./test_fast.jpg 0.8 -3.0 3.0 1601 799
./gbfloat_fast ./test.jpg ./test_fast.jpg 0.8 -3.0 3.0 701 601
./gbfloat_fast ./test.jpg ./test_fast.jpg 0.8 -3.0 3.0 801 789
./gbfloat_fast ./test.jpg ./test_fast.jpg 0.5 -1.0 1.0 741 1201
./gbfloat_fast ./test.jpg ./test_fast.jpg 0.4 -1.0 1.0 1921 611

echo "medium_test"
./gbfloat_fast ./test2.jpg ./test_fast2.jpg 0.6 -2.0 2.0 79 79
./gbfloat_fast ./test2.jpg ./test_fast2.jpg 0.2 -4.0 4.0 421 411
./gbfloat_fast ./test2.jpg ./test_fast2.jpg 0.4 -1.0 1.0 999 691
./gbfloat_fast ./test2.jpg ./test_fast2.jpg 0.8 -3.0 3.0 1601 799
./gbfloat_fast ./test2.jpg ./test_fast2.jpg 0.8 -3.0 3.0 701 601
./gbfloat_fast ./test2.jpg ./test_fast2.jpg 0.8 -3.0 3.0 801 789
./gbfloat_fast ./test2.jpg ./test_fast2.jpg 0.5 -1.0 1.0 741 1201
./gbfloat_fast ./test2.jpg ./test_fast2.jpg 0.4 -1.0 1.0 1921 611

echo "big_test"
./gbfloat_fast ./test3.jpg ./test_fast3.jpg 0.6 -2.0 2.0 79 79
./gbfloat_fast ./test3.jpg ./test_fast3.jpg 0.2 -4.0 4.0 421 411
./gbfloat_fast ./test3.jpg ./test_fast3.jpg 0.4 -1.0 1.0 999 691
./gbfloat_fast ./test3.jpg ./test_fast3.jpg 0.8 -3.0 3.0 1601 799
./gbfloat_fast ./test3.jpg ./test_fast3.jpg 0.8 -3.0 3.0 701 601
./gbfloat_fast ./test3.jpg ./test_fast3.jpg 0.8 -3.0 3.0 801 789
./gbfloat_fast ./test3.jpg ./test_fast3.jpg 0.5 -1.0 1.0 741 1201
./gbfloat_fast ./test3.jpg ./test_fast3.jpg 0.4 -1.0 1.0 1921 611